import java.util.HashMap;

public class Test {
    public static void main(String[] args) {
        SubsekvensRegister register = new SubsekvensRegister();

        String test1 = "TestDataLitenLike/fil1.csv";
        String test2 = "TestDataLitenLike/fil2.csv";
        String test3 = "TestDataLitenLike/fil3.csv";

        HashMap<String, Subsekvens> kart1 = SubsekvensRegister.lesFil(test1);
        HashMap<String, Subsekvens> kart2 = SubsekvensRegister.lesFil(test2);
        HashMap<String, Subsekvens> kart3 = SubsekvensRegister.lesFil(test3);
        HashMap<String, Subsekvens> kart4 = SubsekvensRegister.slaaSammen(kart1, kart2);
        HashMap<String, Subsekvens> kart5 = SubsekvensRegister.slaaSammen(kart3, kart4);

        System.out.println(kart5);
    }
}
